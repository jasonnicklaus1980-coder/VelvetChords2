#!/bin/sh
# Velvet Chords installer for first-generation (32-bit ARM) MPC OS devices. Run on the device as root:
#   sh install.sh [-y]
# Stops MPC, copies the plugin and its song files, backs up MPC.settings, adds the plugin to MPC's
# plugin list and starts MPC again. Safe to run again (upgrades in place). Unofficial: back up first.
set -e
cd "$(dirname "$0")"
NAME='Velvet Chords'; VER='@VERSION@'; SO_DIR='/sdcard/vst'; SO='velvetchords.so'; SKIN='Velvet Chords - VST - Velvet Chords'
YES=0; [ "$1" = "-y" ] && YES=1
die() { echo "error: $*" >&2; exit 1; }

[ "$(id -u)" = 0 ] || die "run as root"
case "$(uname -m)" in armv7*) ;; *) die "this build is for 32-bit ARM MPC OS devices (Gen1); this one is $(uname -m)" ;; esac
SETTINGS=$(ls /media/az01-internal/Settings/*/MPC.settings 2>/dev/null | head -n 1)
[ -n "$SETTINGS" ] || die "MPC.settings not found (not an MPC OS device?)"
command -v systemctl >/dev/null || die "systemctl not found"
[ -d /sdcard ] || die "/sdcard not found"
sha256sum -c SHA256SUMS >/dev/null 2>&1 || die "files damaged (SHA256SUMS mismatch): copy the folder again"
grep -q '/sdcard/Synths' "$SETTINGS" || echo "warning: /sdcard/Synths isn't in MPC's SynthContentLocations; the screen skin may not show"
DATA='/media/az01-internal/Velvet Chords'
[ -d /media/az01-internal ] || DATA='/sdcard/Velvet Chords'

echo "Installing $NAME $VER:"
echo "  $SO_DIR/$SO, screen skin in /sdcard/Synths/$SKIN, song files in $DATA, and an entry in $SETTINGS"
if [ $YES = 0 ]; then
    printf "MPC will be stopped and restarted. Save your project first. Continue? [y/N] "
    read -r ok; case "$ok" in y|Y|yes) ;; *) echo "cancelled"; exit 1 ;; esac
fi

systemctl stop acvs
trap 'systemctl start acvs' EXIT
i=0; while pidof MPC >/dev/null && [ $i -lt 30 ]; do sleep 1; i=$((i + 1)); done
pidof MPC >/dev/null && die "MPC did not stop"

mkdir -p "$SO_DIR" "$DATA" /sdcard/Synths
cp payload/vst/"$SO" "$SO_DIR/$SO.new" && mv "$SO_DIR/$SO.new" "$SO_DIR/$SO"
rm -rf "/sdcard/Synths/$SKIN"; cp -a "payload/Synths/$SKIN" "/sdcard/Synths/$SKIN"
cp -a payload/data/. "$DATA/"

BAK="$SETTINGS.bak-velvetchords-$(date +%Y%m%d-%H%M%S)"
cp "$SETTINGS" "$BAK"
awk -v mode=add -v file="$SO_DIR/$SO" -v entryfile=plugin.xml -f plugin_list.awk "$SETTINGS" > "$SETTINGS.new"
n=$(grep -c "file=\"$SO_DIR/$SO\"" "$SETTINGS.new" || true)
[ "$n" = 1 ] || { rm -f "$SETTINGS.new"; die "settings edit failed (entry count $n); MPC.settings unchanged"; }
if command -v python3 >/dev/null; then
    python3 -c 'import sys, xml.etree.ElementTree as E; E.parse(sys.argv[1])' "$SETTINGS.new" 2>/dev/null ||
        { rm -f "$SETTINGS.new"; die "edited settings aren't valid XML; MPC.settings unchanged"; }
fi
mv "$SETTINGS.new" "$SETTINGS"
sync

echo "Done. Settings backup: $BAK"
echo "Starting MPC. Add '$NAME' to a track from the plugin browser (Instrument plugins)."
