/* Velvet Chords - chord pad instrument for MPC OS (VST2 ABI). */
#include "vst2_abi.h"
#include "engine.h"
#include "export.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <errno.h>

#define VC_EXPORT __attribute__((visibility("default")))
#define VC_UID VC_FOURCC('V', 'l', 'v', 'C')
#define VC_VERSION 1000
#define CHUNK_VERSION 1

enum {
    P_MODE, P_SONG, P_SECTION, P_KEY, P_SCALE, P_TRANSPOSE, P_VOICING, P_INVERSION, P_OCTAVE, P_VL,
    P_STRUM, P_STRUM_DIR, P_ARP, P_ARP_RATE, P_VEL, P_SOUND, P_TONE, P_RELEASE, P_VOLUME,
    P_PAD_BASE, P_LEARN, P_MIDI_OUT,
    P_EDIT_PAD, P_EDIT_ROOT, P_EDIT_TYPE, P_EDIT_BASS, P_EDIT_INV, P_EDIT_OCT, P_EDIT_FOLLOW,
    P_COPY, P_EXPORT, P_NOW, P_INFO,
    /* screen-skin helpers (appended so older projects still load) */
    P_VIEW_BANK, P_ACTIVE,
    P_PADNAME0, P_PADFUNC0 = P_PADNAME0 + 16, P_SCALENOTE0 = P_PADFUNC0 + 16,
    P_SONG_PREV = P_SCALENOTE0 + 12, P_SONG_NEXT, P_SEC_PREV, P_SEC_NEXT, P_SCALE_PREV, P_SCALE_NEXT,
    P_TYPE_PREV, P_TYPE_NEXT, P_EPAD_PREV, P_EPAD_NEXT,
    NUM_PARAMS
};

static int is_display_only(int i) {
    return i == P_NOW || i == P_INFO || (i >= P_PADNAME0 && i < P_SCALENOTE0 + 12);
}

typedef struct { const char *name; int steps; float def; int trigger; } ParamInfo; /* steps 0 = continuous */

static ParamInfo PINFO[NUM_PARAMS];

static void init_param_info(void) {
    static int done = 0;
    if (done) return;
#define P(i, n, s, d, t) PINFO[i].name = n; PINFO[i].steps = s; PINFO[i].def = d; PINFO[i].trigger = t;
    P(P_MODE, "Mode", VC_MODE_COUNT, 0.f, 0)
    P(P_SONG, "Song", VC_NUM_SONGS, 0.f, 0)
    P(P_SECTION, "Section", 8, 0.f, 0)
    P(P_KEY, "Key", 12, 0.f, 0)
    P(P_SCALE, "Scale", VC_NUM_SCALES, 0.f, 0)
    P(P_TRANSPOSE, "Transpose", 25, 0.5f, 0)
    P(P_VOICING, "Voicing", VC_VOICE_COUNT, 0.f, 0)
    P(P_INVERSION, "Inversion", 4, 0.f, 0)
    P(P_OCTAVE, "Octave", 5, 0.5f, 0)
    P(P_VL, "Voice lead", 2, 1.f, 0)
    P(P_STRUM, "Strum", 0, 0.f, 0)
    P(P_STRUM_DIR, "Strum dir", STRUM_COUNT, 0.f, 0)
    P(P_ARP, "Arp", ARP_COUNT, 0.f, 0)
    P(P_ARP_RATE, "Arp rate", RATE_COUNT, 3.f / 5.f, 0)
    P(P_VEL, "Velocity", VEL_COUNT, 0.f, 0)
    P(P_SOUND, "Sound", SY_SOUND_COUNT, 0.f, 0)
    P(P_TONE, "Tone", 0, 0.5f, 0)
    P(P_RELEASE, "Release", 0, 0.3f, 0)
    P(P_VOLUME, "Volume", 0, 0.75f, 0)
    P(P_PAD_BASE, "Pad 1 note", 113, 36.f / 112.f, 0)
    P(P_LEARN, "Learn pad 1", 2, 0.f, 1)
    P(P_MIDI_OUT, "MIDI out", 2, 0.f, 0)
    P(P_EDIT_PAD, "Edit pad", VC_PADS, 0.f, 0)
    P(P_EDIT_ROOT, "Edit root", 12, 0.f, 0)
    P(P_EDIT_TYPE, "Edit type", VC_NUM_QUALITIES + 1, 0.f, 0)
    P(P_EDIT_BASS, "Edit bass", 13, 0.f, 0)
    P(P_EDIT_INV, "Edit inversion", 4, 0.f, 0)
    P(P_EDIT_OCT, "Edit octave", 5, 0.5f, 0)
    P(P_EDIT_FOLLOW, "Edit follows pad", 2, 1.f, 0)
    P(P_COPY, "Copy to Custom", 2, 0.f, 1)
    P(P_EXPORT, "Export MIDI", 2, 0.f, 1)
    P(P_NOW, "Now playing", 1, 0.f, 0)
    P(P_INFO, "Info", 1, 0.f, 0)
    P(P_VIEW_BANK, "Screen bank", 4, 0.f, 0)
    P(P_ACTIVE, "Screen pad", 17, 0.f, 0)
    {
        static char names[44][20];
        static const char *NOTE[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
        for (int k = 0; k < 16; k++) {
            snprintf(names[k], 20, "Pad %d chord", k + 1);
            snprintf(names[16 + k], 20, "Pad %d function", k + 1);
            P(P_PADNAME0 + k, names[k], 1, 0.f, 0)
            P(P_PADFUNC0 + k, names[16 + k], 1, 0.f, 0)
        }
        for (int k = 0; k < 12; k++) {
            snprintf(names[32 + k], 20, "Scale has %s", NOTE[k]);
            P(P_SCALENOTE0 + k, names[32 + k], 2, 0.f, 0)
        }
    }
    P(P_SONG_PREV, "Song prev", 2, 0.f, 1)
    P(P_SONG_NEXT, "Song next", 2, 0.f, 1)
    P(P_SEC_PREV, "Section prev", 2, 0.f, 1)
    P(P_SEC_NEXT, "Section next", 2, 0.f, 1)
    P(P_SCALE_PREV, "Scale prev", 2, 0.f, 1)
    P(P_SCALE_NEXT, "Scale next", 2, 0.f, 1)
    P(P_TYPE_PREV, "Edit type prev", 2, 0.f, 1)
    P(P_TYPE_NEXT, "Edit type next", 2, 0.f, 1)
    P(P_EPAD_PREV, "Edit pad prev", 2, 0.f, 1)
    P(P_EPAD_NEXT, "Edit pad next", 2, 0.f, 1)
#undef P
    done = 1;
}

typedef struct {
    AEffect fx;
    audioMasterCallback host;
    Engine *eng;
    float val[NUM_PARAMS];
    int edit_pad;
    /* layout changes are written here and picked up by the audio thread at the next block */
    LayoutParams lp_pending;
    CustomPad custom_pending[VC_PADS];
    volatile unsigned gen, gen_applied;
    float *scratchL, *scratchR;
    int scratch_n;
    unsigned char *chunk;
    char export_msg[64];
    VstEvents *outEvents;
    VstMidiEvent outMidi[EN_MIDI_OUT];
    char program_name[32];
    PadChord ui_pads[VC_PADS];   /* layout as seen by the screen (built on the UI thread) */
    volatile int audition_req;   /* pad index requested from the screen, -1 none */
    int audition_note, audition_left;
    int seen_pad;
} Plugin;

static int idx_of(const Plugin *p, int i) {
    int s = PINFO[i].steps;
    if (s <= 1) return 0;
    int v = (int)(p->val[i] * (s - 1) + 0.5f);
    return v < 0 ? 0 : v >= s ? s - 1 : v;
}
static float norm_of(int i, int idx) { int s = PINFO[i].steps; return s <= 1 ? 0.f : (float)idx / (float)(s - 1); }

static void copy_str(char *dst, const char *src, int max) {
    int k = 0;
    while (src && src[k] && k < max - 1) { dst[k] = src[k]; k++; }
    dst[k] = 0;
}

static void load_edit_fields(Plugin *p) {
    const CustomPad *c = &p->custom_pending[p->edit_pad];
    p->val[P_EDIT_PAD] = norm_of(P_EDIT_PAD, p->edit_pad);
    p->val[P_EDIT_ROOT] = norm_of(P_EDIT_ROOT, c->root % 12);
    p->val[P_EDIT_TYPE] = norm_of(P_EDIT_TYPE, c->valid ? c->quality + 1 : 0);
    p->val[P_EDIT_BASS] = norm_of(P_EDIT_BASS, c->bass == 255 ? 0 : c->bass % 12 + 1);
    p->val[P_EDIT_INV] = norm_of(P_EDIT_INV, c->inv);
    p->val[P_EDIT_OCT] = norm_of(P_EDIT_OCT, c->oct + 2);
}

static void sync_layout(Plugin *p) {
    LayoutParams *lp = &p->lp_pending;
    lp->mode = idx_of(p, P_MODE);
    lp->song = idx_of(p, P_SONG);
    lp->section = idx_of(p, P_SECTION);
    lp->key = idx_of(p, P_KEY);
    lp->scale = idx_of(p, P_SCALE);
    lp->transpose = idx_of(p, P_TRANSPOSE) - 12;
    lp->voicing = idx_of(p, P_VOICING);
    lp->inversion = idx_of(p, P_INVERSION);
    lp->octave = idx_of(p, P_OCTAVE) - 2;
    lp->voice_lead = idx_of(p, P_VL);
    vc_build_pads(lp, p->custom_pending, p->ui_pads);
    p->gen++;
}

static void refresh_host(Plugin *p) {
    if (p->host) p->host(&p->fx, audioMasterUpdateDisplay, 0, 0, 0, 0.f);
}

/* move a stepped parameter one step (prev/next buttons on the screen) */
static void set_param(Plugin *p, int i, float v, int from_host);
static void step_param(Plugin *p, int i, int dir, int count) {
    if (count < 1) count = 1;
    int x = idx_of(p, i) + dir;
    if (x < 0) x = count - 1;
    if (x >= count) x = 0;
    set_param(p, i, norm_of(i, x), 0);
}

static void build_local(const Plugin *p, PadChord *pads, Voicing *v) {
    vc_build_pads(&p->lp_pending, p->custom_pending, pads);
    vc_voice_pads(&p->lp_pending, pads, v);
}

static void do_copy_to_custom(Plugin *p) {
    static PadChord pads[VC_PADS];
    static Voicing v[VC_PADS];
    build_local(p, pads, v);
    int addOct = 0;
    for (int i = 0; i < VC_PADS; i++) {
        CustomPad *c = &p->custom_pending[i];
        memset(c, 0, sizeof(*c));
        c->bass = 255;
        if (!pads[i].valid || pads[i].spec.quality < 0) continue; /* scale-stacked chords without a name are skipped */
        c->valid = 1;
        c->root = (unsigned char)pads[i].spec.root;
        c->quality = (unsigned char)pads[i].spec.quality;
        c->bass = pads[i].spec.bass < 0 ? 255 : (unsigned char)pads[i].spec.bass;
        c->oct = (signed char)(pads[i].oct + addOct);
        c->inv = (signed char)pads[i].inv;
    }
    p->val[P_MODE] = norm_of(P_MODE, VC_MODE_CUSTOM);
    load_edit_fields(p);
    sync_layout(p);
}

static const char *export_dir(void) {
    const char *d = getenv("VC_EXPORT_DIR");
    if (d && *d) return d;
    /* MPC OS internal drive (where MPC.settings lives); falls back to /sdcard like the plugin itself.
     * mkdir+errno instead of stat(): stat() binds to GLIBC_2.33 on new toolchains. */
    static const char *internal = "/media/az01-internal/Velvet Chords";
    if (mkdir(internal, 0775) == 0 || errno == EEXIST) return internal;
    return "/sdcard/Velvet Chords";
}

static void do_export(Plugin *p, double hostTempo) {
    static PadChord pads[VC_PADS];
    static Voicing v[VC_PADS];
    static MfChord ch[256];
    char fname[160], path[512], text[700], title[160];
    const char *dir = export_dir();
    mkdir(dir, 0775);
    LayoutParams *lp = &p->lp_pending;
    int ok = 0, n = 0;
    build_local(p, pads, v);
    if (lp->mode == VC_MODE_SONG && lp->song < VC_NUM_SONGS) {
        const Song *s = &VC_SONGS[lp->song];
        int sec = vc_song_section_index(lp, 0);
        if (sec >= 0) {
            n = vc_section_chords(s, sec, lp, ch, 256);
            snprintf(title, sizeof(title), "%s - %s - %s%s", s->artist, s->title, s->sections[sec].name, lp->transpose ? " (transposed)" : "");
            vc_safe_filename(title, fname, sizeof(fname));
            vc_provenance_text(s, lp, text, sizeof(text));
            double bpm = s->bpm > 0 ? s->bpm : hostTempo;
            snprintf(path, sizeof(path), "%s/%s.mid", dir, fname);
            ok = vc_midi_write(path, title, text, ch, n, bpm, s->ts_num, s->ts_den);
            int pn = vc_bank_chords(pads, v, 0, ch, 16);
            snprintf(path, sizeof(path), "%s/%s.progression", dir, fname);
            ok = ok && vc_progression_write(path, title, vc_pc_name(s->key_root + lp->transpose, vc_song_flats(s, lp->transpose)), ch, pn);
        }
    } else {
        Engine *e = p->eng;
        int bank = e->last_pad >= 0 ? e->last_pad / 16 : 0;
        snprintf(title, sizeof(title), "Velvet Chords - %s - %s %s - Bank %c", VC_MODE_NAMES[lp->mode], vc_pc_name(lp->key, 0),
                 VC_SCALES[lp->scale].name, 'A' + bank);
        vc_safe_filename(title, fname, sizeof(fname));
        n = vc_bank_chords(pads, v, bank, ch, 16);
        snprintf(path, sizeof(path), "%s/%s.mid", dir, fname);
        ok = n > 0 && vc_midi_write(path, title, "Velvet Chords pad bank, one chord per bar. Original/stylistic chords, not song data.", ch, n, hostTempo, 4, 4);
        snprintf(path, sizeof(path), "%s/%s.progression", dir, fname);
        ok = ok && vc_progression_write(path, title, vc_pc_name(lp->key, 0), ch, n);
    }
    if (ok) snprintf(p->export_msg, sizeof(p->export_msg), "Saved %d chords", n);
    else snprintf(p->export_msg, sizeof(p->export_msg), "Save failed: %s", dir);
}

static double host_tempo(Plugin *p) {
    if (!p->host) return 90.0;
    VstTimeInfo *ti = (VstTimeInfo *)p->host(&p->fx, audioMasterGetTime, 0, kVstTempoValid, 0, 0.f);
    if (ti && (ti->flags & kVstTempoValid) && ti->tempo > 20.0 && ti->tempo < 400.0) return ti->tempo;
    return 90.0;
}

static void set_param(Plugin *p, int i, float v, int from_host) {
    if (i < 0 || i >= NUM_PARAMS) return;
    if (v < 0.f) v = 0.f;
    if (v > 1.f) v = 1.f;
    Engine *e = p->eng;
    if (PINFO[i].trigger) {
        if (v >= 0.5f) {
            if (i == P_LEARN) { e->learn = 1; p->val[i] = 1.f; return; }
            if (i == P_COPY) do_copy_to_custom(p);
            if (i == P_EXPORT) do_export(p, host_tempo(p));
            if (i == P_SONG_PREV || i == P_SONG_NEXT) {
                step_param(p, P_SONG, i == P_SONG_NEXT ? 1 : -1, VC_NUM_SONGS);
                set_param(p, P_SECTION, 0.f, 0);
            }
            if (i == P_SEC_PREV || i == P_SEC_NEXT) {
                int n = VC_SONGS[idx_of(p, P_SONG)].nsections;
                int cur = idx_of(p, P_SECTION);
                if (cur >= n) cur = n - 1;
                cur += (i == P_SEC_NEXT) ? 1 : -1;
                if (cur < 0) cur = n - 1;
                if (cur >= n) cur = 0;
                set_param(p, P_SECTION, norm_of(P_SECTION, cur), 0);
            }
            if (i == P_SCALE_PREV || i == P_SCALE_NEXT) step_param(p, P_SCALE, i == P_SCALE_NEXT ? 1 : -1, VC_NUM_SCALES);
            if (i == P_TYPE_PREV || i == P_TYPE_NEXT) step_param(p, P_EDIT_TYPE, i == P_TYPE_NEXT ? 1 : -1, VC_NUM_QUALITIES + 1);
            if (i == P_EPAD_PREV || i == P_EPAD_NEXT) {
                step_param(p, P_EDIT_PAD, i == P_EPAD_NEXT ? 1 : -1, VC_PADS);
                p->val[P_VIEW_BANK] = norm_of(P_VIEW_BANK, p->edit_pad / 16);
            }
            if (i == P_TYPE_PREV || i == P_TYPE_NEXT) { p->val[P_MODE] = norm_of(P_MODE, VC_MODE_CUSTOM); sync_layout(p); }
            if (i != P_COPY && i != P_EXPORT && i != P_LEARN) refresh_host(p);
        }
        p->val[i] = 0.f;
        return;
    }
    if (is_display_only(i)) return;
    if (i == P_ACTIVE) { /* tapping a pad on the screen auditions it */
        p->val[i] = v;
        int k = idx_of(p, i);
        if (from_host && k > 0) p->audition_req = idx_of(p, P_VIEW_BANK) * 16 + k - 1;
        return;
    }
    if (i == P_VIEW_BANK) { p->val[i] = v; p->val[P_ACTIVE] = 0.f; refresh_host(p); return; }
    p->val[i] = v;
    switch (i) {
    case P_MODE: case P_SONG: case P_SECTION: case P_KEY: case P_SCALE: case P_TRANSPOSE:
    case P_VOICING: case P_INVERSION: case P_OCTAVE: case P_VL:
        sync_layout(p);
        break;
    case P_STRUM: e->strum_ms = v * 150.f; break;
    case P_STRUM_DIR: e->strum_dir = idx_of(p, i); break;
    case P_ARP: e->arp = idx_of(p, i); break;
    case P_ARP_RATE: e->arp_rate = idx_of(p, i); break;
    case P_VEL: e->vel_curve = idx_of(p, i); break;
    case P_SOUND: e->synth.sound = idx_of(p, i); break;
    case P_TONE: e->synth.tone = v; break;
    case P_RELEASE: e->synth.release = v; break;
    case P_VOLUME: e->synth.volume = v; break;
    case P_PAD_BASE: e->pad_base = idx_of(p, i); break;
    case P_MIDI_OUT: {
        int on = idx_of(p, i);
        if (e->midi_out && !on) e->midi_out_flush = 1;
        e->midi_out = on;
        break;
    }
    case P_EDIT_FOLLOW: e->edit_follow = idx_of(p, i); break;
    case P_EDIT_PAD:
        p->edit_pad = idx_of(p, i);
        load_edit_fields(p);
        if (from_host && p->host) p->host(&p->fx, audioMasterUpdateDisplay, 0, 0, 0, 0.f);
        break;
    case P_EDIT_ROOT: case P_EDIT_TYPE: case P_EDIT_BASS: case P_EDIT_INV: case P_EDIT_OCT: {
        CustomPad *c = &p->custom_pending[p->edit_pad];
        int t = idx_of(p, P_EDIT_TYPE);
        c->valid = t > 0;
        c->quality = (unsigned char)(t > 0 ? t - 1 : 0);
        c->root = (unsigned char)idx_of(p, P_EDIT_ROOT);
        int b = idx_of(p, P_EDIT_BASS);
        c->bass = b == 0 ? 255 : (unsigned char)(b - 1);
        c->inv = (signed char)idx_of(p, P_EDIT_INV);
        c->oct = (signed char)(idx_of(p, P_EDIT_OCT) - 2);
        if (from_host) p->val[P_MODE] = norm_of(P_MODE, VC_MODE_CUSTOM); /* edits are heard in Custom mode */
        sync_layout(p);
        break;
    }
    default: break;
    }
}

/* ---------- display text ---------- */

static int getParameterValueInScale(const Plugin *p, int pc) {
    const Scale *sc = &VC_SCALES[idx_of(p, P_SCALE)];
    int key = idx_of(p, P_KEY);
    for (int j = 0; j < sc->n; j++) if ((key + sc->iv[j]) % 12 == pc) return 1;
    return 0;
}

static void pad_label(int idx, char *buf) { buf[0] = (char)('A' + idx / 16); buf[1] = (char)('0' + (idx % 16 + 1) / 10); buf[2] = (char)('0' + (idx % 16 + 1) % 10); buf[3] = 0; }

static void param_display(Plugin *p, int i, char *out, int max) {
    char b[160];
    b[0] = 0;
    int x = idx_of(p, i);
    Engine *e = p->eng;
    const LayoutParams *lp = &p->lp_pending;
    static const char *KEYS[12] = {"C", "C#/Db", "D", "D#/Eb", "E", "F", "F#/Gb", "G", "G#/Ab", "A", "A#/Bb", "B"};
    static const char *INV[4] = {"Root", "1st", "2nd", "3rd"};
    static const char *ONOFF[2] = {"Off", "On"};
    static const char *SDIR[STRUM_COUNT] = {"Up", "Down", "Alternate"};
    static const char *ARPS[ARP_COUNT] = {"Off", "Up", "Down", "Up-down", "Random"};
    static const char *RATES[RATE_COUNT] = {"1/4", "1/8", "1/8T", "1/16", "1/16T", "1/32"};
    static const char *VELS[VEL_COUNT] = {"Linear", "Soft", "Hard", "Fixed"};
    switch (i) {
    case P_MODE: copy_str(b, VC_MODE_NAMES[x], sizeof(b)); break;
    case P_SONG: snprintf(b, sizeof(b), "%s - %s (%d)", VC_SONGS[x].title, VC_SONGS[x].artist, VC_SONGS[x].year); break;
    case P_SECTION: {
        const Song *s = &VC_SONGS[lp->song];
        int si = vc_song_section_index(lp, 0);
        if (si < 0) copy_str(b, "-", sizeof(b));
        else snprintf(b, sizeof(b), "%s (%d/%d)", s->sections[si].name, si + 1, s->nsections);
        break;
    }
    case P_KEY: copy_str(b, KEYS[x], sizeof(b)); break;
    case P_SCALE: copy_str(b, VC_SCALES[x].name, sizeof(b)); break;
    case P_TRANSPOSE: snprintf(b, sizeof(b), "%+d st", x - 12); break;
    case P_VOICING: copy_str(b, VC_VOICE_NAMES[x], sizeof(b)); break;
    case P_INVERSION: case P_EDIT_INV: copy_str(b, INV[x], sizeof(b)); break;
    case P_OCTAVE: case P_EDIT_OCT: snprintf(b, sizeof(b), "%+d", x - 2); break;
    case P_VL: case P_MIDI_OUT: case P_EDIT_FOLLOW: copy_str(b, ONOFF[x], sizeof(b)); break;
    case P_STRUM: if (p->val[i] < 0.004f) copy_str(b, "Off", sizeof(b)); else snprintf(b, sizeof(b), "%d ms", (int)(p->val[i] * 150.f + 0.5f)); break;
    case P_STRUM_DIR: copy_str(b, SDIR[x], sizeof(b)); break;
    case P_ARP: copy_str(b, ARPS[x], sizeof(b)); break;
    case P_ARP_RATE: copy_str(b, RATES[x], sizeof(b)); break;
    case P_VEL: copy_str(b, VELS[x], sizeof(b)); break;
    case P_SOUND: copy_str(b, SY_SOUND_NAMES[x], sizeof(b)); break;
    case P_TONE: case P_RELEASE: case P_VOLUME: snprintf(b, sizeof(b), "%d%%", (int)(p->val[i] * 100.f + 0.5f)); break;
    case P_PAD_BASE: { char nn[8]; x = e->pad_base; vc_note_name(x, 0, nn, sizeof(nn)); snprintf(b, sizeof(b), "%s (%d)", nn, x); break; }
    case P_LEARN: copy_str(b, e->learn ? "Hit pad 1 now" : "Press to learn", sizeof(b)); break;
    case P_EDIT_PAD: pad_label(x, b); break;
    case P_EDIT_ROOT: copy_str(b, KEYS[x], sizeof(b)); break;
    case P_EDIT_TYPE:
        if (x == 0) copy_str(b, "Empty", sizeof(b));
        else snprintf(b, sizeof(b), "%s (%s)", VC_QUALITIES[x - 1].suffix[0] ? VC_QUALITIES[x - 1].suffix : "maj", VC_QUALITIES[x - 1].label);
        break;
    case P_EDIT_BASS: if (x == 0) copy_str(b, "Root", sizeof(b)); else snprintf(b, sizeof(b), "/%s", KEYS[x - 1]); break;
    case P_COPY: copy_str(b, "Press to copy", sizeof(b)); break;
    case P_EXPORT: copy_str(b, p->export_msg[0] ? p->export_msg : "Press to save", sizeof(b)); break;
    case P_NOW: {
        int k = e->last_pad;
        if (k < 0 || k >= VC_PADS) { snprintf(b, sizeof(b), "Last note in: %d", e->last_note_in); break; }
        char lab[4];
        pad_label(k, lab);
        if (!e->pads[k].valid) { snprintf(b, sizeof(b), "%s empty", lab); break; }
        int n = e->pads[k].roman[0] ? snprintf(b, sizeof(b), "%s %s (%s):", lab, e->pads[k].name, e->pads[k].roman)
                                     : snprintf(b, sizeof(b), "%s %s:", lab, e->pads[k].name);
        int fl = lp->mode == VC_MODE_SONG ? vc_song_flats(&VC_SONGS[lp->song], lp->transpose) : vc_prefer_flats(lp->key, vc_scale_is_minor(lp->scale));
        for (int j = 0; j < e->voicings[k].n && n < (int)sizeof(b) - 6; j++) {
            char nn[8];
            vc_note_name(e->voicings[k].notes[j], fl, nn, sizeof(nn));
            n += snprintf(b + n, sizeof(b) - (size_t)n, " %s", nn);
        }
        break;
    }
    case P_VIEW_BANK: b[0] = (char)('A' + x); b[1] = 0; break;
    case P_ACTIVE: if (x == 0) copy_str(b, "-", sizeof(b)); else { pad_label(idx_of(p, P_VIEW_BANK) * 16 + x - 1, b); } break;
    case P_SONG_PREV: case P_SEC_PREV: case P_SCALE_PREV: case P_TYPE_PREV: case P_EPAD_PREV: copy_str(b, "<", sizeof(b)); break;
    case P_SONG_NEXT: case P_SEC_NEXT: case P_SCALE_NEXT: case P_TYPE_NEXT: case P_EPAD_NEXT: copy_str(b, ">", sizeof(b)); break;
    case P_INFO: {
        if (lp->mode == VC_MODE_SONG) {
            const Song *s = &VC_SONGS[lp->song];
            snprintf(b, sizeof(b), "%s, confidence %s, key %s", s->status, s->confidence, s->key);
        } else {
            const Scale *sc = &VC_SCALES[lp->scale];
            int n = snprintf(b, sizeof(b), "Scale:");
            int fl = vc_prefer_flats(lp->key, vc_scale_is_minor(lp->scale));
            for (int j = 0; j < sc->n; j++) n += snprintf(b + n, sizeof(b) - (size_t)n, " %s", vc_pc_name(lp->key + sc->iv[j], fl));
        }
        break;
    }
    default:
        if (i >= P_PADNAME0 && i < P_PADFUNC0 + 16) {
            int k = (i - P_PADNAME0) % 16, isFunc = i >= P_PADFUNC0;
            const PadChord *pc = &p->ui_pads[idx_of(p, P_VIEW_BANK) * 16 + k];
            if (!pc->valid) b[0] = 0; /* empty pad: blank key on screen */
            else if (!isFunc) copy_str(b, pc->name, sizeof(b));
            else if (pc->roman[0]) copy_str(b, pc->roman, sizeof(b));
            else if (pc->spec.quality >= 0) copy_str(b, VC_QUALITIES[pc->spec.quality].label, sizeof(b));
        } else if (i >= P_SCALENOTE0 && i < P_SCALENOTE0 + 12) {
            copy_str(b, getParameterValueInScale(p, i - P_SCALENOTE0) ? "In scale" : "-", sizeof(b));
        }
        break;
    }
    copy_str(out, b, max);
}

/* ---------- chunk (saved inside the MPC project) ---------- */

static int chunk_size(void) { return 12 + NUM_PARAMS * 4 + 4 + VC_PADS * 6 + 4; }

static void w32(unsigned char *b, int *k, uint32_t v) { b[(*k)++] = v & 255; b[(*k)++] = (v >> 8) & 255; b[(*k)++] = (v >> 16) & 255; b[(*k)++] = v >> 24; }
static uint32_t r32(const unsigned char *b, int *k) { uint32_t v = b[*k] | (b[*k + 1] << 8) | (b[*k + 2] << 16) | ((uint32_t)b[*k + 3] << 24); *k += 4; return v; }

static int get_chunk(Plugin *p, void **data) {
    int n = chunk_size(), k = 0;
    if (!p->chunk) p->chunk = (unsigned char *)malloc((size_t)n);
    if (!p->chunk) return 0;
    unsigned char *b = p->chunk;
    memcpy(b, "VLVC", 4); k = 4;
    w32(b, &k, CHUNK_VERSION);
    w32(b, &k, NUM_PARAMS);
    for (int i = 0; i < NUM_PARAMS; i++) { union { float f; uint32_t u; } u; u.f = p->val[i]; w32(b, &k, u.u); }
    w32(b, &k, VC_PADS);
    for (int i = 0; i < VC_PADS; i++) {
        const CustomPad *c = &p->custom_pending[i];
        b[k++] = c->valid; b[k++] = c->root; b[k++] = c->quality; b[k++] = c->bass;
        b[k++] = (unsigned char)c->inv; b[k++] = (unsigned char)c->oct;
    }
    w32(b, &k, (uint32_t)p->edit_pad);
    *data = b;
    return k;
}

static int set_chunk(Plugin *p, const void *data, int size) {
    const unsigned char *b = (const unsigned char *)data;
    if (!b || size < 16 || memcmp(b, "VLVC", 4)) return 0;
    int k = 4;
    uint32_t ver = r32(b, &k), np = r32(b, &k);
    if (ver != CHUNK_VERSION || np > 512 || size < (int)(12 + np * 4 + 4)) return 0;
    for (uint32_t i = 0; i < np; i++) {
        union { float f; uint32_t u; } u;
        u.u = r32(b, &k);
        if (i < NUM_PARAMS && !PINFO[i].trigger) set_param(p, (int)i, u.f, 0);
    }
    uint32_t npads = r32(b, &k);
    if (npads > VC_PADS || size < k + (int)npads * 6) return 0;
    for (uint32_t i = 0; i < npads; i++) {
        CustomPad *c = &p->custom_pending[i];
        c->valid = b[k++] ? 1 : 0; c->root = b[k++] % 12; c->quality = b[k++]; c->bass = b[k++];
        c->inv = (signed char)b[k++]; c->oct = (signed char)b[k++];
        if (c->quality >= VC_NUM_QUALITIES) c->valid = 0;
        if (c->bass != 255) c->bass %= 12;
        if (c->inv < 0 || c->inv > 3) c->inv = 0;
        if (c->oct < -2 || c->oct > 2) c->oct = 0;
    }
    if (size >= k + 4) { p->edit_pad = (int)r32(b, &k); if (p->edit_pad < 0 || p->edit_pad >= VC_PADS) p->edit_pad = 0; }
    load_edit_fields(p);
    sync_layout(p);
    return 1;
}

/* ---------- audio ---------- */

static void ensure_scratch(Plugin *p, int n) {
    if (n <= p->scratch_n) return;
    free(p->scratchL); free(p->scratchR);
    p->scratchL = (float *)calloc((size_t)n, sizeof(float));
    p->scratchR = (float *)calloc((size_t)n, sizeof(float));
    p->scratch_n = (p->scratchL && p->scratchR) ? n : 0;
}

static void apply_pending(Plugin *p) {
    Engine *e = p->eng;
    unsigned g = p->gen;
    if (g == p->gen_applied) return;
    e->lp = p->lp_pending;
    memcpy(e->custom, p->custom_pending, sizeof(e->custom));
    p->gen_applied = g;
    en_rebuild(e);
}

static void send_midi_out(Plugin *p) {
    Engine *e = p->eng;
    if (!e->nout || !p->host) { e->nout = 0; return; }
    int n = e->nout;
    if (!p->outEvents) {
        p->outEvents = (VstEvents *)calloc(1, sizeof(VstEvents) + sizeof(VstEvent *) * EN_MIDI_OUT);
        if (!p->outEvents) { e->nout = 0; return; }
    }
    for (int i = 0; i < n; i++) {
        VstMidiEvent *m = &p->outMidi[i];
        memset(m, 0, sizeof(*m));
        m->type = kVstMidiType;
        m->byteSize = (int32_t)sizeof(VstMidiEvent);
        m->deltaFrames = e->out[i].frame;
        m->midiData[0] = (char)e->out[i].d[0];
        m->midiData[1] = (char)e->out[i].d[1];
        m->midiData[2] = (char)e->out[i].d[2];
        p->outEvents->events[i] = (VstEvent *)m;
    }
    p->outEvents->numEvents = n;
    p->host(&p->fx, audioMasterProcessEvents, 0, 0, p->outEvents, 0.f);
    e->nout = 0;
}

static void render(Plugin *p, float **out, int n, int accumulate) {
    Engine *e = p->eng;
    apply_pending(p);
    e->tempo = host_tempo(p);
    ensure_scratch(p, n); /* normally sized once in effSetBlockSize */
    if (!p->scratch_n) {
        if (!accumulate) { memset(out[0], 0, sizeof(float) * (size_t)n); memset(out[1], 0, sizeof(float) * (size_t)n); }
        e->nin = 0;
        return;
    }
    /* screen audition: a tapped on-screen pad plays for ~0.9 s through the normal pad path */
    int req = p->audition_req;
    if (req >= 0) {
        p->audition_req = -1;
        if (p->audition_note >= 0) en_push_midi(e, 0, 0x80, (unsigned char)p->audition_note, 0);
        int note = e->pad_base + req;
        if (note <= 127) {
            en_push_midi(e, 0, 0x90, (unsigned char)note, 100);
            p->audition_note = note;
            p->audition_left = (int)(e->sr * 0.9f);
        }
    } else if (p->audition_note >= 0) {
        p->audition_left -= n;
        if (p->audition_left <= 0) { en_push_midi(e, 0, 0x80, (unsigned char)p->audition_note, 0); p->audition_note = -1; }
    }
    en_process(e, p->scratchL, p->scratchR, n);
    if (e->events_changed && e->last_pad >= 0) { /* screen follows the played pad */
        p->seen_pad = e->last_pad;
        p->val[P_VIEW_BANK] = norm_of(P_VIEW_BANK, e->last_pad / 16);
        p->val[P_ACTIVE] = norm_of(P_ACTIVE, e->last_pad % 16 + 1);
        e->events_changed = 0;
        refresh_host(p);
    }
    e->events_changed = 0;
    for (int k = 0; k < n; k++) {
        if (accumulate) { out[0][k] += p->scratchL[k]; out[1][k] += p->scratchR[k]; }
        else { out[0][k] = p->scratchL[k]; out[1][k] = p->scratchR[k]; }
    }
    if (idx_of(p, P_PAD_BASE) != e->pad_base) p->val[P_PAD_BASE] = norm_of(P_PAD_BASE, e->pad_base); /* after Learn */
    if (e->edit_pad_request >= 0) { /* "Edit follows pad" in Custom mode */
        p->edit_pad = e->edit_pad_request;
        e->edit_pad_request = -1;
        load_edit_fields(p);
    }
    send_midi_out(p);
}

static void processReplacing(AEffect *fx, float **in, float **out, int32_t n) { (void)in; render((Plugin *)fx->object, out, n, 0); }
static void processAccumulating(AEffect *fx, float **in, float **out, int32_t n) { (void)in; render((Plugin *)fx->object, out, n, 1); }

static void setParameter(AEffect *fx, int32_t i, float v) { set_param((Plugin *)fx->object, i, v, 1); }
static float getParameter(AEffect *fx, int32_t i) {
    Plugin *p = (Plugin *)fx->object;
    if (i < 0 || i >= NUM_PARAMS) return 0.f;
    if (i == P_LEARN) return p->eng->learn ? 1.f : 0.f;
    if (i == P_PAD_BASE) return norm_of(P_PAD_BASE, p->eng->pad_base); /* may change via Learn */
    if (i >= P_SCALENOTE0 && i < P_SCALENOTE0 + 12) return getParameterValueInScale(p, i - P_SCALENOTE0) ? 1.f : 0.f;
    return p->val[i];
}

static void destroy(Plugin *p) {
    free(p->scratchL); free(p->scratchR); free(p->chunk); free(p->outEvents); free(p->eng); free(p);
}

static intptr_t dispatcher(AEffect *fx, int32_t op, int32_t index, intptr_t value, void *ptr, float opt) {
    Plugin *p = (Plugin *)fx->object;
    switch (op) {
    case effOpen: return 0;
    case effClose: destroy(p); return 0;
    case effSetSampleRate: en_set_sr(p->eng, opt); return 0;
    case effSetBlockSize: ensure_scratch(p, (int)value); return 0;
    case effMainsChanged: if (!value) en_reset(p->eng); return 0;
    case effGetParamName: if (index >= 0 && index < NUM_PARAMS && ptr) copy_str((char *)ptr, PINFO[index].name, 32); return 0;
    case effGetParamLabel: if (ptr) ((char *)ptr)[0] = 0; return 0;
    case effGetParamDisplay: if (index >= 0 && index < NUM_PARAMS && ptr) param_display(p, index, (char *)ptr, 64); return 0;
    case effCanBeAutomated: return (index >= 0 && index < NUM_PARAMS && !PINFO[index].trigger && !is_display_only(index) && index != P_ACTIVE && index != P_VIEW_BANK) ? 1 : 0;
    case effGetProgram: return 0;
    case effSetProgram: return 0;
    case effGetProgramName: case effGetProgramNameIndexed: if (ptr) copy_str((char *)ptr, p->program_name, 24); return op == effGetProgramNameIndexed ? 1 : 0;
    case effSetProgramName: if (ptr) copy_str(p->program_name, (const char *)ptr, 24); return 0;
    case effGetChunk: return ptr ? get_chunk(p, (void **)ptr) : 0;
    case effSetChunk: return set_chunk(p, ptr, (int)value);
    case effProcessEvents: {
        VstEvents *ev = (VstEvents *)ptr;
        if (!ev) return 0;
        for (int i = 0; i < ev->numEvents; i++) {
            VstEvent *e = ev->events[i];
            if (!e || e->type != kVstMidiType) continue;
            VstMidiEvent *m = (VstMidiEvent *)e;
            en_push_midi(p->eng, m->deltaFrames, (unsigned char)m->midiData[0], (unsigned char)m->midiData[1], (unsigned char)m->midiData[2]);
        }
        return 1;
    }
    case effGetPlugCategory: return kPlugCategSynth;
    case effGetEffectName: if (ptr) copy_str((char *)ptr, "Velvet Chords", 32); return 1;
    case effGetVendorString: if (ptr) copy_str((char *)ptr, "Velvet Chords", 64); return 1;
    case effGetProductString: if (ptr) copy_str((char *)ptr, "Velvet Chords", 64); return 1;
    case effGetVendorVersion: return VC_VERSION;
    case effCanDo: {
        const char *s = (const char *)ptr;
        if (!s) return 0;
        if (!strcmp(s, "receiveVstEvents") || !strcmp(s, "receiveVstMidiEvent") || !strcmp(s, "sendVstEvents") || !strcmp(s, "sendVstMidiEvent")) return 1;
        return 0;
    }
    case effGetVstVersion: return 2400;
    case effVendorSpecific: /* test hook: 'VCdb' -> active synth voices (value 0) or held chords (value 1) */
        if (index == VC_FOURCC('V', 'C', 'd', 'b')) return value ? en_owner_count(p->eng) : sy_active(&p->eng->synth);
        return 0;
    case effGetTailSize: return 0;
    default: return 0;
    }
}

VC_EXPORT AEffect *VSTPluginMain(audioMasterCallback host) {
    if (host && !host(0, audioMasterVersion, 0, 0, 0, 0.f)) return 0;
    init_param_info();
    Plugin *p = (Plugin *)calloc(1, sizeof(Plugin));
    if (!p) return 0;
    p->eng = (Engine *)calloc(1, sizeof(Engine));
    if (!p->eng) { free(p); return 0; }
    p->host = host;
    en_init(p->eng, 44100.f);
    copy_str(p->program_name, "Default", 32);
    p->audition_req = -1;
    p->audition_note = -1;
    p->seen_pad = -1;
    memcpy(p->custom_pending, p->eng->custom, sizeof(p->custom_pending));
    for (int i = 0; i < NUM_PARAMS; i++) p->val[i] = PINFO[i].def;
    for (int i = 0; i < NUM_PARAMS; i++)
        if (!PINFO[i].trigger && !(i >= P_EDIT_PAD && i <= P_EDIT_OCT)) set_param(p, i, PINFO[i].def, 0);
    load_edit_fields(p); /* edit fields mirror the seeded custom pad A01 */
    sync_layout(p);

    AEffect *fx = &p->fx;
    fx->magic = kEffectMagic;
    fx->dispatcher = dispatcher;
    fx->process = processAccumulating;
    fx->processReplacing = processReplacing;
    fx->setParameter = setParameter;
    fx->getParameter = getParameter;
    fx->numPrograms = 1;
    fx->numParams = NUM_PARAMS;
    fx->numInputs = 0;
    fx->numOutputs = 2;
    fx->flags = effFlagsCanReplacing | effFlagsIsSynth | effFlagsProgramChunks;
    fx->ioRatio = 1.f;
    fx->object = p;
    fx->uniqueID = VC_UID;
    fx->version = VC_VERSION;
    return fx;
}

/* some hosts look for "main" instead of "VSTPluginMain" */
VC_EXPORT AEffect *vc_main_alias(audioMasterCallback host) __asm__("main");
AEffect *vc_main_alias(audioMasterCallback host) { return VSTPluginMain(host); }
