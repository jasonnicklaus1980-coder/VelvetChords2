#include "engine.h"
#include <string.h>

void en_set_sr(Engine *e, float sr) {
    if (sr < 1000.f) sr = 44100.f;
    e->sr = sr;
    e->synth.sr = sr;
}

void en_init(Engine *e, float sr) {
    memset(e, 0, sizeof(*e));
    sy_init(&e->synth, sr);
    en_set_sr(e, sr);
    e->lp.mode = VC_MODE_SONG;
    e->lp.scale = 0;
    e->lp.voicing = VC_VOICE_BASS_UPPER;
    e->lp.voice_lead = 1;
    e->pad_base = 36; /* MPC "C1"; use Learn if your pads send something else */
    e->tempo = 90.0;
    e->last_pad = -1;
    e->last_note_in = -1;
    e->edit_pad_request = -1;
    e->edit_follow = 1;
    e->rng = 0x12345u;
    /* seed the custom banks with the R&B kit in C so Custom mode is playable out of the box */
    LayoutParams kit = e->lp;
    kit.mode = VC_MODE_RNB;
    PadChord tmp[VC_PADS];
    vc_build_pads(&kit, e->custom, tmp);
    for (int i = 0; i < 32; i++) {
        CustomPad *c = &e->custom[i];
        c->valid = (unsigned char)tmp[i].valid;
        c->root = (unsigned char)tmp[i].spec.root;
        c->quality = (unsigned char)(tmp[i].spec.quality < 0 ? 0 : tmp[i].spec.quality);
        c->bass = tmp[i].spec.bass < 0 ? 255 : (unsigned char)tmp[i].spec.bass;
        c->inv = 0;
        c->oct = (signed char)tmp[i].oct;
    }
    e->dirty = 1;
    en_rebuild(e);
}

void en_rebuild(Engine *e) {
    e->dirty = 0;
    vc_build_pads(&e->lp, e->custom, e->pads);
    vc_voice_pads(&e->lp, e->pads, e->voicings);
}

float en_vel_curve(int curve, int vel) {
    float x = vel / 127.f;
    switch (curve) {
    case VEL_SOFT: x = 1.f - (1.f - x) * (1.f - x); break;
    case VEL_HARD: x = x * x; break;
    case VEL_FIXED: x = 0.8f; break;
    default: break;
    }
    return x < 0.03f ? 0.03f : x > 1.f ? 1.f : x;
}

static void emit(Engine *e, int frame, unsigned char s, unsigned char d1, unsigned char d2) {
    if (e->nout >= EN_MIDI_OUT) return;
    MidiMsg *m = &e->out[e->nout++];
    m->frame = frame;
    m->d[0] = s; m->d[1] = d1; m->d[2] = d2;
}

static OwnerRec *find_owner(Engine *e, int owner) {
    if (!owner) return 0;
    for (int i = 0; i < EN_OWNERS; i++) if (e->owners[i].owner == owner) return &e->owners[i];
    return 0;
}

static void note_on_slot(Engine *e, OwnerRec *r, int slot, int frame) {
    if (slot < 0 || slot >= r->n || r->sounding[slot]) return;
    int note = r->notes[slot];
    sy_note_on(&e->synth, note, r->vel, r->owner);
    r->sounding[slot] = 1;
    if (e->out_ref[note]++ == 0 && e->midi_out) emit(e, frame, 0x90, (unsigned char)note, (unsigned char)(r->vel * 127.f + 0.5f));
}

static void note_off_slot(Engine *e, OwnerRec *r, int slot, int frame) {
    if (slot < 0 || slot >= r->n || !r->sounding[slot]) return;
    int note = r->notes[slot];
    sy_release(&e->synth, note, r->owner);
    r->sounding[slot] = 0;
    if (e->out_ref[note] > 0 && --e->out_ref[note] == 0 && e->midi_out) emit(e, frame, 0x80, (unsigned char)note, 0);
}

static void release_owner(Engine *e, OwnerRec *r, int frame) {
    if (!r || !r->owner) return;
    int k = 0;
    for (int i = 0; i < e->nqueue; i++) if (e->queue[i].owner != r->owner) e->queue[k++] = e->queue[i];
    e->nqueue = k;
    if (e->arp_owner == r->owner) { e->arp_owner = 0; e->arp_slot = -1; }
    for (int s = 0; s < r->n; s++) note_off_slot(e, r, s, frame);
    sy_release(&e->synth, -1, r->owner);
    for (int n = 0; n < 128; n++) if (e->pad_owner[n] == r->owner) e->pad_owner[n] = 0;
    memset(r, 0, sizeof(*r));
}

static OwnerRec *alloc_owner(Engine *e, int frame) {
    OwnerRec *oldest = 0;
    for (int i = 0; i < EN_OWNERS; i++) {
        if (!e->owners[i].owner) return &e->owners[i];
        if (!oldest || e->owners[i].owner < oldest->owner) oldest = &e->owners[i];
    }
    release_owner(e, oldest, frame);
    return oldest;
}

void en_reset(Engine *e) {
    for (int i = 0; i < EN_OWNERS; i++) if (e->owners[i].owner) release_owner(e, &e->owners[i], 0);
    e->nqueue = 0;
    e->arp_owner = 0;
    e->sustain = 0;
    memset(e->pad_owner, 0, sizeof(e->pad_owner));
    for (int n = 0; n < 128; n++) {
        if (e->out_ref[n] > 0 && e->midi_out) emit(e, 0, 0x80, (unsigned char)n, 0);
        e->out_ref[n] = 0;
    }
    sy_kill_all(&e->synth);
}

static void pad_off(Engine *e, int note, int frame) {
    int owner = e->pad_owner[note];
    if (!owner) return;
    e->pad_owner[note] = 0;
    OwnerRec *r = find_owner(e, owner);
    if (!r) return;
    r->held = 0;
    if (e->sustain) r->sustained = 1;
    else release_owner(e, r, frame);
}

static void pad_on(Engine *e, int note, int vel, int frame) {
    e->last_note_in = note;
    e->events_changed = 1;
    if (e->learn) {
        e->pad_base = note > 112 ? 112 : note;
        e->learn = 0;
    }
    int idx = note - e->pad_base;
    if (idx < 0 || idx >= VC_PADS) return;
    if (e->pad_owner[note]) release_owner(e, find_owner(e, e->pad_owner[note]), frame);
    e->last_pad = idx;
    if (e->edit_follow && e->lp.mode == VC_MODE_CUSTOM) e->edit_pad_request = idx;
    const Voicing *v = &e->voicings[idx];
    if (!e->pads[idx].valid || v->n == 0) return;

    OwnerRec *r = alloc_owner(e, frame);
    if (++e->next_owner <= 0) e->next_owner = 1;
    r->owner = e->next_owner;
    r->held = 1;
    r->sustained = 0;
    r->n = v->n;
    memcpy(r->notes, v->notes, (size_t)v->n);
    memset(r->sounding, 0, sizeof(r->sounding));
    r->vel = en_vel_curve(e->vel_curve, vel);
    e->pad_owner[note] = r->owner;

    if (e->arp != ARP_OFF) {
        e->arp_owner = r->owner;
        e->arp_idx = -1;
        e->arp_dirn = 1;
        e->arp_slot = -1;
        e->arp_next = e->now + frame;
        return;
    }
    int dir = e->strum_dir;
    if (dir == STRUM_ALT) { dir = e->strum_flip ? STRUM_DOWN : STRUM_UP; e->strum_flip ^= 1; }
    double step = e->strum_ms * 0.001 * e->sr;
    for (int i = 0; i < r->n; i++) {
        int slot = dir == STRUM_DOWN ? r->n - 1 - i : i;
        int64_t delay = (int64_t)(step * i + 0.5);
        if (delay <= 0) note_on_slot(e, r, slot, frame);
        else if (e->nqueue < EN_QUEUE) {
            QEvent *q = &e->queue[e->nqueue++];
            q->when = e->now + frame + delay;
            q->owner = r->owner;
            q->slot = (unsigned char)slot;
            q->vel = 0;
        }
    }
}

static void handle_midi(Engine *e, const MidiMsg *m, int frame) {
    int st = m->d[0] & 0xF0;
    if (st == 0x90 && m->d[2] > 0) pad_on(e, m->d[1] & 127, m->d[2], frame);
    else if (st == 0x80 || st == 0x90) pad_off(e, m->d[1] & 127, frame);
    else if (st == 0xB0) {
        int cc = m->d[1], val = m->d[2];
        if (cc == 64) {
            int on = val >= 64;
            if (e->sustain && !on) {
                e->sustain = 0;
                for (int i = 0; i < EN_OWNERS; i++)
                    if (e->owners[i].owner && e->owners[i].sustained && !e->owners[i].held) release_owner(e, &e->owners[i], frame);
            }
            e->sustain = on;
        } else if (cc == 120 || cc == 123) {
            for (int i = 0; i < EN_OWNERS; i++) if (e->owners[i].owner) release_owner(e, &e->owners[i], frame);
            e->sustain = 0;
            if (cc == 120) sy_kill_all(&e->synth);
        } else if (cc == 121) {
            if (e->sustain) {
                e->sustain = 0;
                for (int i = 0; i < EN_OWNERS; i++)
                    if (e->owners[i].owner && e->owners[i].sustained && !e->owners[i].held) release_owner(e, &e->owners[i], frame);
            }
        }
    }
}

void en_push_midi(Engine *e, int frame, unsigned char s, unsigned char d1, unsigned char d2) {
    if (e->nin >= EN_MIDI_IN) return;
    MidiMsg *m = &e->in[e->nin++];
    m->frame = frame < 0 ? 0 : frame;
    m->d[0] = s; m->d[1] = d1; m->d[2] = d2;
}

static double arp_beats(int rate) {
    switch (rate) {
    case RATE_4: return 1.0;
    case RATE_8: return 0.5;
    case RATE_8T: return 1.0 / 3.0;
    case RATE_16: return 0.25;
    case RATE_16T: return 1.0 / 6.0;
    default: return 0.125;
    }
}

static void arp_step(Engine *e, int frame) {
    OwnerRec *r = find_owner(e, e->arp_owner);
    if (!r || r->n == 0) { e->arp_owner = 0; return; }
    if (e->arp_slot >= 0) note_off_slot(e, r, e->arp_slot, frame);
    int n = r->n, i = e->arp_idx;
    switch (e->arp) {
    case ARP_DOWN: i = (i <= 0) ? n - 1 : i - 1; break;
    case ARP_UPDOWN:
        if (n == 1) i = 0;
        else {
            if (i < 0) { i = 0; e->arp_dirn = 1; }
            else {
                i += e->arp_dirn;
                if (i >= n) { e->arp_dirn = -1; i = n - 2; }
                if (i < 0) { e->arp_dirn = 1; i = 1; }
            }
        }
        break;
    case ARP_PLAYED: /* random */
        e->rng = e->rng * 1664525u + 1013904223u;
        i = (int)((e->rng >> 16) % (unsigned)n);
        break;
    default: i = (i + 1) % n; break;
    }
    e->arp_idx = i;
    e->arp_slot = i;
    note_on_slot(e, r, i, frame);
    double tempo = e->tempo > 20.0 && e->tempo < 400.0 ? e->tempo : 90.0;
    int64_t step = (int64_t)(e->sr * 60.0 / tempo * arp_beats(e->arp_rate) + 0.5);
    if (step < 16) step = 16;
    e->arp_next += step;
    if (e->arp_next <= e->now + frame) e->arp_next = e->now + frame + step;
}

static void sort_in(Engine *e) {
    for (int i = 1; i < e->nin; i++) {
        MidiMsg v = e->in[i];
        int j = i - 1;
        while (j >= 0 && e->in[j].frame > v.frame) { e->in[j + 1] = e->in[j]; j--; }
        e->in[j + 1] = v;
    }
}

void en_process(Engine *e, float *L, float *R, int n) {
    if (e->dirty) en_rebuild(e);
    memset(L, 0, sizeof(float) * (size_t)n);
    memset(R, 0, sizeof(float) * (size_t)n);
    if (e->midi_out_flush) { /* MIDI out switched off: silence anything we left hanging */
        for (int k = 0; k < 128; k++) if (e->out_ref[k] > 0) emit(e, 0, 0x80, (unsigned char)k, 0);
        e->midi_out_flush = 0;
    }
    sort_in(e);
    int ii = 0, pos = 0;
    while (pos < n) {
        while (ii < e->nin && e->in[ii].frame <= pos) handle_midi(e, &e->in[ii++], pos);
        /* due strum notes */
        for (int q = 0; q < e->nqueue;) {
            if (e->queue[q].when <= e->now + pos) {
                QEvent ev = e->queue[q];
                e->queue[q] = e->queue[--e->nqueue];
                OwnerRec *r = find_owner(e, ev.owner);
                if (r) note_on_slot(e, r, ev.slot, pos);
            } else q++;
        }
        if (e->arp_owner && e->arp != ARP_OFF && e->arp_next <= e->now + pos) arp_step(e, pos);
        if (e->arp == ARP_OFF && e->arp_owner) e->arp_owner = 0;

        int next = n;
        if (ii < e->nin && e->in[ii].frame < next) next = e->in[ii].frame;
        for (int q = 0; q < e->nqueue; q++) {
            int64_t d = e->queue[q].when - e->now;
            if (d < next) next = (int)d;
        }
        if (e->arp_owner && e->arp != ARP_OFF) {
            int64_t d = e->arp_next - e->now;
            if (d < next) next = (int)d;
        }
        if (next <= pos) next = pos + 1;
        if (next > n) next = n;
        sy_render(&e->synth, L + pos, R + pos, next - pos);
        pos = next;
    }
    while (ii < e->nin) handle_midi(e, &e->in[ii++], n - 1); /* frames beyond the block */
    e->nin = 0;
    e->now += n;
}

int en_owner_count(const Engine *e) {
    int c = 0;
    for (int i = 0; i < EN_OWNERS; i++) c += e->owners[i].owner != 0;
    return c;
}
