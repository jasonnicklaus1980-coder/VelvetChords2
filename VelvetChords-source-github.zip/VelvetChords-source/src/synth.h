#ifndef VC_SYNTH_H
#define VC_SYNTH_H

#define SY_VOICES 48
enum { SY_EPIANO, SY_PAD, SY_ORGAN, SY_SILENT, SY_SOUND_COUNT };
extern const char *SY_SOUND_NAMES[SY_SOUND_COUNT];

typedef struct {
    int active, note, owner, released, sound, stage;
    unsigned age;
    float vel, amp, attK, decMul, relMul, inc, pan;
    float ph[3];
    float modEnv, modMul, tineEnv, tineMul, modDepth;
    float lpA, lp1, lp2;
} SVoice;

typedef struct {
    SVoice v[SY_VOICES];
    float sr;
    int sound;
    float tone, release, volume;
    unsigned age;
} Synth;

void sy_init(Synth *s, float sr);
void sy_note_on(Synth *s, int note, float vel, int owner);
void sy_release(Synth *s, int note, int owner); /* note < 0: every voice of owner */
void sy_kill_all(Synth *s);
void sy_render(Synth *s, float *L, float *R, int n); /* adds into L/R */
int sy_active(const Synth *s);

#endif
