#include "synth.h"
#include "vcmath.h"
#include <string.h>

const char *SY_SOUND_NAMES[SY_SOUND_COUNT] = {"Electric piano", "Soft pad", "Organ", "Silent (MIDI only)"};

void sy_init(Synth *s, float sr) {
    vc_math_init();
    memset(s, 0, sizeof(*s));
    s->sr = sr > 1000.f ? sr : 44100.f;
    s->tone = 0.5f;
    s->release = 0.3f;
    s->volume = 0.7f;
}

static SVoice *alloc_voice(Synth *s) {
    SVoice *best = 0;
    for (int i = 0; i < SY_VOICES; i++) if (!s->v[i].active) return &s->v[i];
    /* steal: prefer released voices, then the oldest */
    for (int i = 0; i < SY_VOICES; i++) {
        SVoice *v = &s->v[i];
        if (!best || (v->released && !best->released) || (v->released == best->released && v->age < best->age)) best = v;
    }
    return best;
}

void sy_note_on(Synth *s, int note, float vel, int owner) {
    if (s->sound == SY_SILENT || note < 0 || note > 127) return;
    SVoice *v = alloc_voice(s);
    float sr = s->sr;
    memset(v, 0, sizeof(*v));
    v->active = 1;
    v->note = note;
    v->owner = owner;
    v->sound = s->sound;
    v->vel = vel;
    v->age = ++s->age;
    float hz = vc_midi_hz(note);
    v->inc = hz / sr;
    float pan = (note - 60) / 60.f;
    v->pan = pan > 0.35f ? 0.35f : pan < -0.35f ? -0.35f : pan;
    double rel = 0.05 + s->release * 2.5;
    switch (v->sound) {
    case SY_EPIANO: {
        v->attK = 1.f - vc_decay_mul(0.0015, sr);
        double tau = 1.0 + 3.5 * vc_exp2(-(note - 48) / 24.0);
        if (tau > 6.0) tau = 6.0;
        v->decMul = vc_decay_mul(tau, sr);
        v->relMul = vc_decay_mul(rel * 0.4, sr);
        v->modEnv = 1.f;
        v->modMul = vc_decay_mul(0.25 + 0.3 * (1.f - s->tone), sr);
        v->modDepth = (0.5f + 2.2f * s->tone) * (0.35f + 0.65f * vel);
        v->tineEnv = 1.f;
        v->tineMul = vc_decay_mul(0.025, sr);
        break;
    }
    case SY_PAD: {
        v->attK = 1.f - vc_decay_mul(0.18, sr);
        v->decMul = 1.f;
        v->relMul = vc_decay_mul(0.08 + rel * 0.5, sr);
        double fc = 250.0 + s->tone * 4500.0 + vel * 1200.0;
        if (fc > sr * 0.45) fc = sr * 0.45;
        v->lpA = 1.f - (float)vc_exp(-6.283185307 * fc / sr);
        v->ph[1] = 0.37f; v->ph[2] = 0.71f;
        break;
    }
    default: { /* organ */
        v->attK = 1.f - vc_decay_mul(0.003, sr);
        v->decMul = 1.f;
        v->relMul = vc_decay_mul(0.02 + rel * 0.2, sr);
        break;
    }
    }
}

void sy_release(Synth *s, int note, int owner) {
    for (int i = 0; i < SY_VOICES; i++) {
        SVoice *v = &s->v[i];
        if (v->active && !v->released && v->owner == owner && (note < 0 || v->note == note)) v->released = 1;
    }
}

void sy_kill_all(Synth *s) {
    for (int i = 0; i < SY_VOICES; i++) s->v[i].active = 0;
}

int sy_active(const Synth *s) {
    int n = 0;
    for (int i = 0; i < SY_VOICES; i++) n += s->v[i].active;
    return n;
}

static inline float blep_saw(float ph, float inc) {
    float y = 2.f * ph - 1.f;
    if (ph < inc) { float t = ph / inc; y -= t + t - t * t - 1.f; }
    else if (ph > 1.f - inc) { float t = (ph - 1.f) / inc; y -= t * t + t + t + 1.f; }
    return y;
}

void sy_render(Synth *s, float *L, float *R, int n) {
    static const float H[6] = {1.f, 2.f, 3.f, 4.f, 6.f, 8.f};
    float drawbar[6] = {1.f, 0.8f, 0.55f * s->tone + 0.15f, 0.35f * s->tone, 0.25f * s->tone, 0.18f * s->tone};
    float g = s->volume * s->volume * 0.22f;
    for (int i = 0; i < SY_VOICES; i++) {
        SVoice *v = &s->v[i];
        if (!v->active) continue;
        float gl = g * (1.f - v->pan), gr = g * (1.f + v->pan);
        for (int k = 0; k < n; k++) {
            /* envelope: attack -> decay (EP) or sustain (pad/organ) -> release */
            if (v->released) v->amp *= v->relMul;
            else if (v->stage == 0) {
                v->amp += (v->vel - v->amp) * v->attK;
                if (v->amp >= v->vel * 0.995f) v->stage = 1;
            } else v->amp *= v->decMul;
            float y;
            if (v->sound == SY_EPIANO) {
                float m = vc_sinc(v->ph[1]) * v->modDepth * (0.2f + 0.8f * v->modEnv);
                y = vc_sinc(v->ph[0] + m * 0.159155f);
                if (v->inc * 14.f < 0.45f) y += vc_sinc(v->ph[2]) * v->tineEnv * 0.12f;
                v->modEnv *= v->modMul;
                v->tineEnv *= v->tineMul;
                v->ph[0] = vc_wrap1(v->ph[0] + v->inc);
                v->ph[1] = vc_wrap1(v->ph[1] + v->inc);
                v->ph[2] = vc_wrap1(v->ph[2] + v->inc * 14.f);
            } else if (v->sound == SY_PAD) {
                float a = blep_saw(v->ph[0], v->inc * 1.004f), b = blep_saw(v->ph[1], v->inc * 0.996f);
                float x = 0.5f * (a + b) + 0.35f * vc_sinc(v->ph[2] * 0.5f);
                v->lp1 += (x - v->lp1) * v->lpA;
                v->lp2 += (v->lp1 - v->lp2) * v->lpA;
                y = v->lp2 * 0.8f;
                v->ph[0] = vc_wrap1(v->ph[0] + v->inc * 1.004f);
                v->ph[1] = vc_wrap1(v->ph[1] + v->inc * 0.996f);
                v->ph[2] = v->ph[2] + v->inc;
                if (v->ph[2] >= 2.f) v->ph[2] -= 2.f;
            } else {
                y = 0.f;
                for (int h = 0; h < 6; h++) if (v->inc * H[h] < 0.45f) y += vc_sinc(v->ph[0] * H[h]) * drawbar[h];
                y *= 0.32f;
                v->ph[0] = vc_wrap1(v->ph[0] + v->inc);
            }
            float a = v->amp;
            L[k] += y * a * gl;
            R[k] += y * a * gr;
        }
        float lvl = v->amp;
        if ((v->released || (v->sound == SY_EPIANO && v->stage == 1)) && lvl < 0.0002f) v->active = 0;
    }
    for (int k = 0; k < n; k++) { L[k] = vc_softclip(L[k]); R[k] = vc_softclip(R[k]); }
}
