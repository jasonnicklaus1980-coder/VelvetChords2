#ifndef VC_ENGINE_H
#define VC_ENGINE_H
#include "layouts.h"
#include "synth.h"
#include <stdint.h>

#define EN_QUEUE 1024
#define EN_OWNERS 128
#define EN_MIDI_IN 1024
#define EN_MIDI_OUT 1024

enum { STRUM_UP, STRUM_DOWN, STRUM_ALT, STRUM_COUNT };
enum { ARP_OFF, ARP_UP, ARP_DOWN, ARP_UPDOWN, ARP_PLAYED /* random order */, ARP_COUNT };
enum { RATE_4, RATE_8, RATE_8T, RATE_16, RATE_16T, RATE_32, RATE_COUNT };
enum { VEL_LINEAR, VEL_SOFT, VEL_HARD, VEL_FIXED, VEL_COUNT };

typedef struct { int64_t when; int owner; unsigned char slot, vel; } QEvent;
typedef struct { int frame; unsigned char d[3]; } MidiMsg;

typedef struct {
    int owner, held, sustained;
    int n;
    unsigned char notes[VC_MAX_NOTES];
    unsigned char sounding[VC_MAX_NOTES];
    float vel;
} OwnerRec;

typedef struct Engine {
    Synth synth;
    float sr;
    int64_t now; /* absolute sample clock at the start of the current block */

    /* layout */
    LayoutParams lp;
    CustomPad custom[VC_PADS];
    PadChord pads[VC_PADS];
    Voicing voicings[VC_PADS];
    volatile int dirty;

    /* performance settings */
    int pad_base, learn, midi_out, midi_out_flush, edit_follow;
    float strum_ms;
    int strum_dir, strum_flip;
    int arp, arp_rate, vel_curve;
    double tempo;

    /* state */
    int pad_owner[128];
    OwnerRec owners[EN_OWNERS];
    int next_owner;
    int sustain;
    QEvent queue[EN_QUEUE];
    int nqueue;
    int arp_owner, arp_idx, arp_dirn, arp_slot;
    int64_t arp_next;
    unsigned rng;
    int out_ref[128];

    MidiMsg in[EN_MIDI_IN];
    int nin;
    MidiMsg out[EN_MIDI_OUT];
    int nout;

    int last_pad; /* -1 none */
    int last_note_in;
    int events_changed; /* set when last_pad / pad_base / edit pad changed (for host display refresh) */
    int edit_pad_request; /* -1 none, else pad index to select for editing */
} Engine;

void en_init(Engine *e, float sr);
void en_set_sr(Engine *e, float sr);
void en_rebuild(Engine *e);
void en_reset(Engine *e); /* all notes off, clear queues */
void en_push_midi(Engine *e, int frame, unsigned char s, unsigned char d1, unsigned char d2);
void en_process(Engine *e, float *L, float *R, int n); /* replaces L/R */
int en_owner_count(const Engine *e);
float en_vel_curve(int curve, int vel);

#endif
