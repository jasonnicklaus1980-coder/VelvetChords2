/* vc_export: writes every song section and the R&B kits as MIDI + .progression files, plus a JSON
 * database where each chord symbol sits next to the exact MIDI notes it plays.
 * Uses the same chord/voicing code as the plugin, so files and pads can't disagree. */
#include "../src/export.h"
#include "../src/layouts.h"
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>

static void mkdirs(const char *path) {
    char tmp[512];
    snprintf(tmp, sizeof(tmp), "%s", path);
    for (char *p = tmp + 1; *p; p++) if (*p == '/') { *p = 0; mkdir(tmp, 0775); *p = '/'; }
    mkdir(tmp, 0775);
}

static void jstr(FILE *f, const char *s) {
    fputc('"', f);
    for (; s && *s; s++) { if (*s == '"' || *s == '\\') fputc('\\', f); fputc(*s, f); }
    fputc('"', f);
}

int main(int argc, char **argv) {
    const char *out = argc > 1 ? argv[1] : "out";
    char dir[512], path[700], name[200], fname[200], text[800];
    MfChord ch[256];
    int files = 0;
    LayoutParams lp;
    memset(&lp, 0, sizeof(lp));
    lp.voicing = VC_VOICE_BASS_UPPER;
    lp.voice_lead = 1;

    snprintf(path, sizeof(path), "%s/database.json", out);
    mkdirs(out);
    FILE *db = fopen(path, "w");
    if (!db) { perror(path); return 1; }
    fprintf(db, "{\n  \"generator\": \"Velvet Chords vc_export\",\n  \"note_numbering\": \"MIDI note numbers; names use MPC convention (60 = C3)\",\n"
                "  \"voicing\": \"performance_voicing = generated 'Bass + upper' voicing with voice leading; NOT a transcription of the original record\",\n  \"songs\": [\n");

    for (int si = 0; si < VC_NUM_SONGS; si++) {
        const Song *s = &VC_SONGS[si];
        lp.song = si;
        snprintf(dir, sizeof(dir), "%s/midi/%ds", out, (s->year / 10) * 10);
        mkdirs(dir);
        snprintf(path, sizeof(path), "%s/progressions/songs", out);
        mkdirs(path);
        fprintf(db, "    {\"song_id\": "); jstr(db, s->id);
        fprintf(db, ", \"title\": "); jstr(db, s->title);
        fprintf(db, ", \"artist\": "); jstr(db, s->artist);
        fprintf(db, ", \"writers\": "); jstr(db, s->writers);
        fprintf(db, ", \"release_year\": %d, \"decade\": \"%ds\", \"style\": ", s->year, (s->year / 10) * 10); jstr(db, s->genre);
        fprintf(db, ", \"original_key\": "); jstr(db, s->key);
        fprintf(db, ", \"tempo_bpm\": %s, \"time_signature\": ", s->bpm > 0 ? "\"see data\"" : "null");
        if (s->timesig) jstr(db, s->timesig); else fprintf(db, "null");
        fprintf(db, ", \"recording_version\": "); jstr(db, s->recording);
        fprintf(db, ", \"verification_status\": "); jstr(db, s->status);
        fprintf(db, ", \"confidence_level\": "); jstr(db, s->confidence);
        fprintf(db, ", \"analysis_notes\": "); jstr(db, s->notes);
        fprintf(db, ", \"source_reference\": \"Recalled common charts and harmonic analysis; no licensed transcription consulted. Verify against the recording.\"");
        fprintf(db, ",\n     \"sections\": [\n");
        for (int sec = 0; sec < s->nsections; sec++) {
            lp.section = sec;
            int n = vc_section_chords(s, sec, &lp, ch, 256);
            snprintf(name, sizeof(name), "%s - %s - %s", s->artist, s->title, s->sections[sec].name);
            vc_safe_filename(name, fname, sizeof(fname));
            vc_provenance_text(s, &lp, text, sizeof(text));
            snprintf(path, sizeof(path), "%s/%s.mid", dir, fname);
            if (vc_midi_write(path, name, text, ch, n, s->bpm > 0 ? s->bpm : 90.0, s->ts_num, s->ts_den)) files++;
            /* .progression: one entry per pad (repeats collapsed), same as the plugin's song bank */
            static PadChord pads[VC_PADS];
            static Voicing v[VC_PADS];
            LayoutParams sp = lp;
            sp.mode = VC_MODE_SONG;
            vc_build_pads(&sp, 0, pads);
            vc_voice_pads(&sp, pads, v);
            MfChord pc[16];
            int pn = vc_bank_chords(pads, v, 0, pc, 16);
            snprintf(path, sizeof(path), "%s/progressions/songs/%s.progression", out, fname);
            if (vc_progression_write(path, name, vc_pc_name(s->key_root, vc_song_flats(s, 0)), pc, pn)) files++;

            fprintf(db, "       {\"section_name\": "); jstr(db, s->sections[sec].name);
            fprintf(db, ", \"chord_events\": [\n");
            int padno = 0;
            const char *lastn = 0;
            for (int i = 0; i < n; i++) {
                if (!lastn || strcmp(lastn, ch[i].name)) padno++;
                lastn = ch[i].name;
                ChordSpec c;
                vc_chord_parse(ch[i].name, &c);
                char nn[8];
                fprintf(db, "         {\"bar_number\": %d, \"beat_position\": %.2f, \"duration_beats\": %.2f, \"chord_symbol\": ",
                        (int)(ch[i].start_beats / (s->ts_num * 4.0f / s->ts_den)) + 1,
                        ch[i].start_beats - (int)(ch[i].start_beats / (s->ts_num * 4.0f / s->ts_den)) * (s->ts_num * 4.0f / s->ts_den) + 1.f,
                        ch[i].dur_beats);
                jstr(db, ch[i].name);
                fprintf(db, ", \"root_note\": \"%s\", \"bass_note\": \"%s\", \"midi_note_numbers\": [", vc_pc_name(c.root, vc_song_flats(s, 0)),
                        vc_pc_name(c.bass >= 0 ? c.bass : c.root, vc_song_flats(s, 0)));
                for (int j = 0; j < ch[i].n; j++) fprintf(db, "%s%d", j ? ", " : "", ch[i].notes[j]);
                fprintf(db, "], \"voicing_notes\": \"");
                for (int j = 0; j < ch[i].n; j++) { vc_note_name(ch[i].notes[j], vc_song_flats(s, 0), nn, sizeof(nn)); fprintf(db, "%s%s", j ? " " : "", nn); }
                fprintf(db, "\", \"bass_in_pad_chord\": true, \"pad_number\": \"A%02d\"}%s\n", padno, i + 1 < n ? "," : "");
            }
            fprintf(db, "       ]}%s\n", sec + 1 < s->nsections ? "," : "");
        }
        fprintf(db, "     ]}%s\n", si + 1 < VC_NUM_SONGS ? "," : "");
    }
    fprintf(db, "  ]\n}\n");
    fclose(db);

    /* R&B kits, every key, major + minor, banks A and B */
    snprintf(dir, sizeof(dir), "%s/progressions/rnb-kits", out);
    mkdirs(dir);
    char mdir[512];
    snprintf(mdir, sizeof(mdir), "%s/midi/rnb-kits", out);
    mkdirs(mdir);
    for (int minor = 0; minor < 2; minor++)
        for (int key = 0; key < 12; key++) {
            static PadChord pads[VC_PADS];
            static Voicing v[VC_PADS];
            LayoutParams kp = lp;
            kp.mode = VC_MODE_RNB;
            kp.key = key;
            kp.scale = minor ? 1 : 0;
            vc_build_pads(&kp, 0, pads);
            vc_voice_pads(&kp, pads, v);
            for (int bank = 0; bank < 2; bank++) {
                int n = vc_bank_chords(pads, v, bank, ch, 16);
                const char *kn = vc_pc_name(key, vc_prefer_flats(key, minor));
                snprintf(name, sizeof(name), "RnB kit %s %s bank %c", kn, minor ? "minor" : "major", 'A' + bank);
                vc_safe_filename(name, fname, sizeof(fname));
                snprintf(path, sizeof(path), "%s/%s.progression", dir, fname);
                if (vc_progression_write(path, name, kn, ch, n)) files++;
                snprintf(path, sizeof(path), "%s/%s.mid", mdir, fname);
                if (vc_midi_write(path, name, "Velvet Chords R&B kit: original stylistic chord palette, not song data. One chord per bar.", ch, n, 90.0, 4, 4)) files++;
            }
        }
    /* pad reference: which pad plays which chord (default settings: Bass + upper voicing, voice leading on) */
    snprintf(path, sizeof(path), "%s/PAD_REFERENCE.md", out);
    FILE *pr = fopen(path, "w");
    if (pr) {
        fprintf(pr, "# Pad reference\n\nPads A01-A16 = MIDI notes 36-51 by default (bank B 52-67, C 68-83, D 84-99); use *Learn pad 1* if your pads send other notes. "
                    "Note names use the MPC convention (60 = C3). Voicings are generated performance voicings, not transcriptions of the records.\n\n## Songs\n");
        for (int si = 0; si < VC_NUM_SONGS; si++) {
            const Song *s = &VC_SONGS[si];
            static PadChord pads[VC_PADS];
            static Voicing v[VC_PADS];
            LayoutParams sp = lp;
            sp.mode = VC_MODE_SONG; sp.song = si; sp.section = 0;
            vc_build_pads(&sp, 0, pads);
            vc_voice_pads(&sp, pads, v);
            fprintf(pr, "\n### %s - %s (%d)\n%s, confidence %s, key %s\n\n| Pad | Section | Chord | Function | Notes |\n|---|---|---|---|---|\n",
                    s->title, s->artist, s->year, s->status, s->confidence, s->key);
            for (int p = 0; p < VC_PADS; p++) {
                if (!pads[p].valid) continue;
                int sec = vc_song_section_index(&sp, p / 16);
                fprintf(pr, "| %c%02d | %s | %s | %s | ", 'A' + p / 16, p % 16 + 1, s->sections[sec].name, pads[p].name, pads[p].roman);
                for (int j = 0; j < v[p].n; j++) { char nn[8]; vc_note_name(v[p].notes[j], vc_song_flats(s, 0), nn, sizeof(nn)); fprintf(pr, "%s%s", j ? " " : "", nn); }
                fprintf(pr, " |\n");
            }
        }
        for (int minor = 0; minor < 2; minor++) {
            static PadChord pads[VC_PADS];
            LayoutParams kp = lp;
            kp.mode = VC_MODE_RNB; kp.key = 0; kp.scale = minor;
            vc_build_pads(&kp, 0, pads);
            fprintf(pr, "\n## R&B kit, C %s (transposes with Key)\n\n| Pad | Chord | Function |\n|---|---|---|\n", minor ? "minor" : "major");
            for (int p = 0; p < 32; p++) fprintf(pr, "| %c%02d | %s | %s |\n", 'A' + p / 16, p % 16 + 1, pads[p].name, pads[p].roman);
        }
        fprintf(pr, "\nBanks C and D of the R&B kit repeat A and B one octave up.\n");
        fclose(pr);
    }
    printf("wrote %d files + database.json to %s\n", files, out);
    return 0;
}
